package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small self-contained bootstrap compatible with the Gradle wrapper entry point. */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path project = Path.of(System.getProperty("user.dir")).toAbsolutePath();
        Path propertiesFile = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesFile)) {
            throw new IllegalStateException("Missing " + propertiesFile);
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(propertiesFile)) {
            properties.load(input);
        }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.isBlank()) {
            throw new IllegalStateException("distributionUrl is not configured");
        }
        distributionUrl = distributionUrl.replace("\\:", ":");
        String archiveName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distributionName = archiveName.replaceFirst("\\.zip$", "");

        String gradleUserHome = System.getenv("GRADLE_USER_HOME");
        if (gradleUserHome == null || gradleUserHome.isBlank()) {
            gradleUserHome = Path.of(System.getProperty("user.home"), ".gradle").toString();
        }
        Path installRoot = Path.of(gradleUserHome, "wrapper", "dists", distributionName, "abuqaoud-bootstrap");
        Path gradleHome = installRoot.resolve(distributionName);
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        Path gradleScript = gradleHome.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");

        if (!Files.isRegularFile(gradleScript)) {
            Files.createDirectories(installRoot);
            Path archive = installRoot.resolve(archiveName);
            System.out.println("Downloading Gradle distribution: " + distributionUrl);
            download(distributionUrl, archive);
            unzipSafely(archive, installRoot);
            Files.deleteIfExists(archive);
        }
        if (!Files.isRegularFile(gradleScript)) {
            throw new IOException("Gradle was downloaded but its launcher was not found: " + gradleScript);
        }
        if (!windows) {
            gradleScript.toFile().setExecutable(true, false);
        }

        ProcessBuilder builder;
        if (windows) {
            builder = new ProcessBuilder("cmd.exe", "/c", "\"" + gradleScript + "\"");
        } else {
            builder = new ProcessBuilder(gradleScript.toString());
        }
        for (String arg : args) builder.command().add(arg);
        builder.directory(project.toFile());
        builder.inheritIO();
        int exitCode = builder.start().waitFor();
        if (exitCode != 0) System.exit(exitCode);
    }

    private static void download(String url, Path destination) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) URI.create(url).toURL().openConnection();
        connection.setConnectTimeout(30_000);
        connection.setReadTimeout(120_000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "AbuQaoud-Gradle-Bootstrap/1.0");
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
            throw new IOException("Gradle download failed with HTTP " + status);
        }
        try (InputStream input = connection.getInputStream()) {
            Files.copy(input, destination, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            connection.disconnect();
        }
    }

    private static void unzipSafely(Path archive, Path destination) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = destination.resolve(entry.getName()).normalize();
                if (!output.startsWith(destination.normalize())) {
                    throw new IOException("Unsafe path in Gradle distribution archive");
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    Files.copy(zip, output, StandardCopyOption.REPLACE_EXISTING);
                }
                zip.closeEntry();
            }
        }
    }
}
